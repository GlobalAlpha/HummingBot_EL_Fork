echo
echo "The connect.sh script is no longer in use.  Please use start.sh"
echo