#!/usr/bin/env python

from collections import namedtuple
from typing import List
from datetime import datetime
import pandas as pd

from hummingbot.core.event.events import (
    TradeType,
    TradeFee,
    OrderType,
)


class Trade(namedtuple("_Trade", "trading_pair, side, price, amount, order_type, market, timestamp, trade_fee")):
    trading_pair: str
    side: TradeType
    price: float
    amount: float
    order_type: OrderType
    market: str
    timestamp: float
    trade_fee: TradeFee

    @classmethod
    def to_pandas(cls, trades: List):
        columns: List[str] = ["trading_pair",
                              "price",
                              "quantity",
                              "order_type",
                              "trade_side",
                              "market",
                              "timestamp",
                              "fee_percent",
                              "flat_fee / gas"]
        data = []
        for trade in trades:
            if len(trade.trade_fee.flat_fees) == 0:
                flat_fee_str = "None"
            else:
                fee_strs = [f"{fee_tuple[0]} {fee_tuple[1]}" for fee_tuple in trade.trade_fee.flat_fees]
                flat_fee_str = ",".join(fee_strs)

            data.append([
                trade.trading_pair,
                trade.price,
                trade.amount,
                "market" if trade.order_type is OrderType.MARKET else "limit",
                "buy" if trade.side is TradeType.BUY else "sell",
                trade.market,
                datetime.fromtimestamp(trade.timestamp).strftime("%Y-%m-%d %H:%M:%S"),
                trade.trade_fee.percent,
                flat_fee_str,
            ])

        return pd.DataFrame(data=data, columns=columns)
