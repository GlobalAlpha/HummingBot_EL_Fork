# DDEX test
web3_test_private_key_ddex = "<INSERT_HERE>"
test_ddex_web3_provider_list = ["<INSERT_HERE>"]
test_ddex_erc20_token_address_1 = "<INSERT_HERE>"
test_ddex_erc20_token_address_2 = "<INSERT_HERE>"

# Radar Relay test
web3_private_key_radar = "<INSERT_HERE>"
mn_zerox_token_address = "<INSERT_HERE>"
mn_weth_token_address = "<INSERT_HERE>"

# Bamboo Relay test
web3_private_key_bamboo = "<INSERT_HERE>"
test_bamboo_relay_chain_id = 3
# Ropsten token addresses
test_bamboo_relay_base_token_symbol = "<INSERT_HERE>"
test_bamboo_relay_quote_token_symbol = "<INSERT_HERE>"
test_bamboo_relay_base_token_address = "<INSERT_HERE>"
test_bamboo_relay_quote_token_address = "<INSERT_HERE>"

# Web3 wallet test (Ropsten)
web3_test_private_key_a = "<INSERT_HERE>"
web3_test_private_key_b = "<INSERT_HERE>"
web3_test_private_key_c = "<INSERT_HERE>"
test_web3_provider_list = ["<INSERT_HERE>"]
test_erc20_token_address = "<INSERT_HERE>"

