#!/usr/bin/env python

from .dev_simple_trade import SimpleTradeStrategy


__all__ = [
    SimpleTradeStrategy
]
