#!/usr/bin/env python

from .dev_0_hello_world import HelloWorldStrategy


__all__ = [
    HelloWorldStrategy
]
