# Docker Autobuild Hooks

This folder containers hooks for docker autobuild.

[Hummingbot builds](https://hub.docker.com/r/coinalpha/hummingbot/builds)