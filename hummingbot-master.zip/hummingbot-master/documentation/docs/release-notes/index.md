# Release Notes

We generally release a new version of Hummingbot every 4 weeks, along with periodic intermittent releases.

The latest stable release is **[0.24.1](/release-notes/0.24.1)**, released on March 2, 2020.