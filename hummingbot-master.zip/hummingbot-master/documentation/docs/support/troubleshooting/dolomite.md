# Dolomite Error Messages

This error below indicates that an account on Dolomite must be created.

```
... WARNING - No Dolomite account for <wallet_address>.
```

Follow the instructions in [Dolomite - Using the Connector](https://docs.hummingbot.io/connectors/dolomite/#using-the-connector).
