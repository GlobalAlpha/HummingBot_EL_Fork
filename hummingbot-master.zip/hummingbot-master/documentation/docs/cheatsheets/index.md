# Cheatsheets

We have compiled lists of handy commands for Hummingbot:

* [Docker Commands](/cheatsheets/docker): Installing, running, and updating Hummingbot Docker images
* [Source Commands](/cheatsheets/source): Installing, running, and updating Hummingbot from source
* [Client Commands](/cheatsheets/client): Commands available in the Hummingbot client interface