
Please follow our [twitter](https://twitter.com/hummingbot_io) or join our [discord](https://discordapp.com/invite/2MN3UWg) to get the latest bounty information.  